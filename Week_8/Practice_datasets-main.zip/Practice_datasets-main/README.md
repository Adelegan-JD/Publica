# Practice_datasets
This repository contain dataset for practice.
