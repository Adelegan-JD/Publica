# Escape Sequence
dish_name = input("Can you give me the name of a popular Nigerian dish?: ")
dish_state = input("In what State is this dish most popular?: ")
print(f"{dish_name} is a very popular food \nand it is commonly eaten in\ {dish_state} State" )
