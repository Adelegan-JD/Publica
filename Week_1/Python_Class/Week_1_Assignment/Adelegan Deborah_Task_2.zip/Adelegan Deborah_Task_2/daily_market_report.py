# Daily Market Report
market_name = input("What is the name of the market please?: ")
number_of_traders = input("How many traders are in this market?: ")
market_revenue = int(input("How much do you make in this market daily?: "))
print(f"According to the report from one of the traders in {market_name} market, the average amount made daily from sales is about {market_revenue:,} naira")