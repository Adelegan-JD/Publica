# School Registration Form
student_name = input("Kindly enter your name: ")    #This requests for the name of the student
student_class = input("What class are you?: ")   # This requests for the class of the student
student_sor = input("That state are you from?: ")     # This requests for the student's state of origin
# The code below displays the name, class and state of the origin of the student
print("Student " + student_name + " " + "is in " + student_class + " and comes from " + student_sor + " " + "State")