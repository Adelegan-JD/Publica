# TASK 1
# Write a Python Program that prints the following information on separate lines:
# Your full name
# Your university
# Your loocal government area
# Your favourite Nigerian food

# Solution 

# The code below gives my information line by line
print("TASK 1")
print("My name is Adelegan Deborah\nI am currently studying at Ogun State Technical School\nI hail from Abeokuta South Local Government\nMy favourite Nigerian food is Pounded Yam and Egusi Soup")
      

      
# TASK 2
# Write a Python Program that stores your name and state of origin in variables, and also prints a message

# Solution
print ("TASK 2")
name = "Adelegan Deborah"       # This is my name saved as a variable
state_of_origin = "Ogun State"  # This is my state of origin stored as a variable
# Written below is a statement that displays my information
print("Hi there, it's a pleasure to meet you. My name is " + name +   "and I am an indigene of" " " + state_of_origin)

# TASK 3
# Print a simple timetable for a day in a Nigerian secondary school using tab spacing and newlines.

# Solution
# To carry out this task, I will do the follwing
# Step 1: Write out the Time and Subjects in their respective columns
print("TASK 3")
print("\t   TIME\t\t    SUBJECT\n\n\t08:10-08:50\t   Mathematics\n\t08:50-09:30\t   Mathematics\n\t09:30-10:10\t   Yoruba\n\t10:10-10:20\t   Short Break\n\t10:20-11:00\t   English\n\t11:00-11:40 \t   Biology\n\t11:40-12:10\t   Long Break\n\t12:10-12:50 \t   Physics/Accounting/Lit-In-Eng\n\t12:50-01:30 \t   Geography/Book-Keeping/Government\n\t01:30-02:10 \t   Civic Education\n\t02:10-02:50\t   Economics/CRS/TD\n\t02:50-03:30\t   Economics/CRS/TD")


      

# TASK 4
# Write a Python Program that uses variables to store:
# Your name
# Your class
# Your best subject
# Then use an f-string to format and print them in a sentence

# Solution
name = "Adelegan Deborah"
my_class = "AI Engineering"
best_subject = "Python"
# The code below displays my name, class and favourite subject using the f-string.
print("TASK 4")
print(f"My name is {name} . I am enrolled in the {my_class} class. and my best subject so far is {best_subject}")


      
# TASK 5
# Write a short 3-line poem about Nigeria and print it using triple quotes("""""")

# Solution
# This is a short poem on Nigeria
print("TASK 5")
print("""      
      Nigeria is a land filled with milk and honey,
      And though her leaders rule with the rod of injustice,
      I believe, and we believe that Nigeria will burgeon
      """)
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
